package com.ltimindtree;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.ltimindtree.entity.Customer;
import com.ltimindtree.exception.CustomerNotFoundException;
import com.ltimindtree.repository.CustomerRepository;
import com.ltimindtree.service.impl.CustomerServiceImpl;



@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)
@SpringBootTest(classes= {ServiceMockitoTest.class})
public class ServiceMockitoTest {
	
	@Mock
	private CustomerRepository customerRep;
	
	@InjectMocks
	private CustomerServiceImpl customerService;
	
	@Test
	@Order(1)
	public void testGetCustomerById() {
		int id=1;
		Customer exceptedCustomer=new Customer();
		when(customerRep.findById(id)).thenReturn(Optional.of(exceptedCustomer));
		Customer actualCustomer=customerService.getCustomerById(id);
		assertEquals(exceptedCustomer,actualCustomer);
	}
	
	@Test
	@Order(2)
	public void test_saveCustomer() {
		Customer customer=new Customer(1, "Josh", "josh@gmail.com", "2Ba12", "856743");
		when(customerRep.save(customer)).thenReturn(customer);  //mocking
		Customer savedCustomer= customerService.saveCustomer(customer);
		//assertEquals(myCustomer, customerService.saveCustomer(customer));
		assertEquals(customer, savedCustomer);
	}
	
	@Test
	@Order(3)
	public void test_updateCountry() throws CustomerNotFoundException {
		int id=1;
		//Customer customer=new Customer(1, "Josh", "josh@gmail.com", "2Ba12", "856743");
		Customer existingCustomer=new Customer();
		Customer updatedCustomer=new Customer();
		when(customerRep.findById(id)).thenReturn(Optional.of(existingCustomer));
		when(customerRep.save(existingCustomer)).thenReturn(updatedCustomer);
		
		Customer result=customerService.updateCustomer(updatedCustomer, id);
		assertEquals(existingCustomer, result);
		assertEquals(updatedCustomer.getCustomerName(), existingCustomer.getCustomerName());
		assertEquals(updatedCustomer.getEmail(), existingCustomer.getEmail());
		assertEquals(updatedCustomer.getPassword(), existingCustomer.getPassword());
		assertEquals(updatedCustomer.getCustomerCellNo(), existingCustomer.getCustomerCellNo());
		
		
		
		//when(customerRep.save(customer)).thenReturn(customer);  //mocking
		//assertEquals(myCustomer, customerService.updateCustomer(customer, 1));
	}
	
	@Test 
	@Order(4)
	public void test_deleteCountry() throws CustomerNotFoundException {
		int id=1;
		when(customerRep.findById(id)).thenReturn(Optional.of(new Customer()));
		customerService.deleteCustomer(id);
		verify(customerRep, times(1)).deleteById(id);
	}

}
